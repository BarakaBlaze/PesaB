# Pesa: Android app project

This folder is your Pesa money tracker wrapped as an Android app with Capacitor.
The app itself is `www/index.html`.

## Option A: build the APK online (no Android Studio needed)

1. Create a free account at github.com and make a new **private** repository.
2. Upload everything in this folder to it (drag the files into the "uploading an existing file" page).
   - The hidden folder `.github` may not upload. If the Actions tab shows no workflow, choose
     **Add file > Create new file**, name it `.github/workflows/build-apk.yml`, and paste the
     contents of `github-workflow.yml`.
3. Open the **Actions** tab, pick **Build Android APK**, and press **Run workflow**.
4. After about 5 to 8 minutes, open the finished run and download **pesa-apk** from Artifacts.
   Unzip it to get `app-debug.apk`.
5. Send the APK to your phone, open it, and allow "install from unknown sources" when asked.

## Option B: build on your computer

Needs Node 22+, JDK 21 and Android Studio.

    npm install
    npm run sync
    npx cap open android

In Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Notes

- Package name is `com.pesa.moneytracker` (in `capacitor.config.json`). Change it before the first
  install if you want your own, for example `com.yourcompany.pesa`.
- Your data is stored on the phone. Clearing the app's storage or uninstalling erases it, so use
  Settings > Backup and currency now and then.
- The APK is signed with a debug key. That is fine for your own phone. For Google Play you need a
  release build signed with your own keystore.
- After you change `www/index.html`, run the build again to get a new APK.
